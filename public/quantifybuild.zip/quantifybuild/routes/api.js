const express = require('express')
const router = express.Router()

const r3 = (v) => Math.round(v*1000)/1000

router.post('/concrete', (req, res) => {
  const { length_m, width_m, thickness_mm } = req.body
  const L = Number(length_m) || 0
  const W = Number(width_m) || 0
  const th = (Number(thickness_mm)||0)/1000
  if(L<=0||W<=0||th<=0) return res.status(400).json({ error: 'Invalid dimensions' })

  const vol = L*W*th
  const weight = vol*2400

  const cement_volume = vol*(1/5.5)
  const cement_density = 1440
  const cement_weight = cement_volume*cement_density
  const cement_bags = cement_weight/50

  const sand_volume = vol*(1.5/5.5)
  const agg_volume = vol*(3/5.5)

  res.json({ volume_m3: r3(vol), weight_kg: Math.round(weight), cement_bags: r3(cement_bags), sand_m3: r3(sand_volume), aggregate_m3: r3(agg_volume) })
})

router.post('/brick', (req, res) => {
  const { wall_area_m2, brick_length_mm, brick_width_mm, mortar_thickness_mm } = req.body
  const A = Number(wall_area_m2) || 0
  const bl = (Number(brick_length_mm)||190)/1000
  const bw = (Number(brick_width_mm)||90)/1000
  const mortar = (Number(mortar_thickness_mm)||10)/1000
  if(A<=0) return res.status(400).json({ error: 'Invalid wall area' })

  const estimated_bricks = Math.ceil(A * (1/(bl*bw*0.09)))
  const mortar_volume = r3(estimated_bricks * 0.0002)

  res.json({ bricks_needed: estimated_bricks, mortar_volume_m3: mortar_volume })
})

router.post('/steel', (req, res) => {
  const items = Array.isArray(req.body) ? req.body : [req.body]
  let total = 0
  const bars = []
  for(const it of items){
    const len = Number(it.length_m)||0
    const d = Number(it.dia_mm)||0
    const qty = Number(it.quantity)||1
    if(len<=0||d<=0) continue
    const w = len * (d*d) * 0.00617 * qty
    bars.push({ length_m: len, dia_mm: d, quantity: qty, weight_kg: r3(w) })
    total += w
  }
  res.json({ total_weight_kg: r3(total), bars })
})

router.post('/shuttering', (req, res) => {
  const { length_m, height_m, sides } = req.body
  const L = Number(length_m)||0
  const H = Number(height_m)||0
  const s = Number(sides)||2
  if(L<=0||H<=0) return res.status(400).json({ error: 'Invalid dimensions' })
  const area = L*H*s
  res.json({ area_m2: r3(area) })
})

router.post('/cost', (req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items : []
  let total = 0
  const breakdown = []
  for(const it of items){
    const qty = Number(it.quantity)||0
    const uc = Number(it.unit_cost)||0
    const cost = qty*uc
    breakdown.push({ name: it.name || 'item', quantity: qty, unit_cost: uc, cost: r3(cost) })
    total += cost
  }
  res.json({ total_cost: r3(total), breakdown })
})

module.exports = router
