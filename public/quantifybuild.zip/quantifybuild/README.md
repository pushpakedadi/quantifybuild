1. Save the project files with the same structure.
2. In the project root run:
   npm install
3. Start server:
   npm start
4. Open http://localhost:3000 in your browser

Notes:
- The backend provides APIs at /api/* used by the frontend.
- You can extend formulas in routes/api.js for your preferred standards and mix designs.
