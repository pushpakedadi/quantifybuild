QuantifyBuild — Fullstack Estimator (Black & Gold theme)

Quick start:

1. Extract files.
2. In project root run:
     npm install
3. Start server:
     npm start
4. Open http://localhost:3000 in your browser

To host frontend on GitHub Pages:
- Push entire repo to GitHub.
- In repository settings > Pages set branch to main and folder to /public.
- Commit the public folder files (index.html, styles.css) to make Pages serve them.

To host backend:
- Deploy this repo to Render or Railway as a Node web service.
- Set build command: npm install
- Start command: npm start
- Use the Render service URL as apiBase in frontend (replace /api)
