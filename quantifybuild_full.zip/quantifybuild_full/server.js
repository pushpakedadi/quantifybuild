const express = require('express')
const path = require('path')
const cors = require('cors')
const bodyParser = require('body-parser')

const app = express()
app.use(cors())
app.use(bodyParser.json())

// static frontend
app.use(express.static(path.join(__dirname, 'public')))

// APIs
const api = require('./routes/api')
app.use('/api', api)

const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.log(`QuantifyBuild server running on http://localhost:${PORT}`))
