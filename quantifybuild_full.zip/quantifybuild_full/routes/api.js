const express = require('express')
const router = express.Router()
const r3 = (v) => Math.round(v*1000)/1000

// Concrete: metric inputs length_m, width_m, thickness_mm
router.post('/concrete', (req, res) => {
  const { length_m, width_m, thickness_mm } = req.body
  const L = Number(length_m) || 0
  const W = Number(width_m) || 0
  const th = (Number(thickness_mm)||0)/1000
  if(L<=0||W<=0||th<=0) return res.status(400).json({ error: 'Invalid dimensions' })

  const vol = L*W*th // m3
  const weight = vol*2400 // kg

  // Mix 1:1.5:3 (cement:sand:agg) for approximate M20
  const totalParts = 1 + 1.5 + 3
  const cement_volume = vol*(1/totalParts)
  const cement_density = 1440 // kg/m3
  const cement_weight = cement_volume * cement_density
  const cement_bags = cement_weight / 50

  const sand_m3 = vol*(1.5/totalParts)
  const agg_m3 = vol*(3/totalParts)

  res.json({
    volume_m3: r3(vol),
    weight_kg: Math.round(weight),
    cement_bags: r3(cement_bags),
    cement_weight_kg: Math.round(cement_weight),
    sand_m3: r3(sand_m3),
    aggregate_m3: r3(agg_m3)
  })
})

// Brick calculator: wall_area_m2
router.post('/brick', (req, res) => {
  const { wall_area_m2, brick_length_mm, brick_width_mm, brick_height_mm, mortar_thickness_mm } = req.body
  const A = Number(wall_area_m2) || 0
  const bl = (Number(brick_length_mm)||190)/1000
  const bw = (Number(brick_width_mm)||90)/1000
  const bh = (Number(brick_height_mm)||90)/1000
  const mortar = (Number(mortar_thickness_mm)||10)/1000
  if(A<=0) return res.status(400).json({ error: 'Invalid wall area' })

  // bricks per m2 (approx) = 1 / (bl * bh) considering stretcher bond and mortar allowance
  const bricks_per_m2 = 1 / (bl * bh) * 0.95 // factor for wastage/mortar
  const bricks_needed = Math.ceil(bricks_per_m2 * A)
  // mortar volume estimate per brick (approx)
  const mortar_volume_m3 = r3(bricks_needed * 0.00022) // 0.00022 m3 per brick approx

  res.json({ bricks_needed, mortar_volume_m3 })
})

// Steel: accepts array of bars
router.post('/steel', (req, res) => {
  const items = Array.isArray(req.body) ? req.body : [req.body]
  let total = 0
  const bars = []
  for(const it of items){
    const len = Number(it.length_m)||0
    const d = Number(it.dia_mm)||0
    const qty = Number(it.quantity)||1
    if(len<=0||d<=0) continue
    // weight (kg) = length(m) * (dia_mm^2) * 0.006165 (standard factor) * qty
    const w = len * (d*d) * 0.006165 * qty
    bars.push({ length_m: len, dia_mm: d, quantity: qty, weight_kg: r3(w) })
    total += w
  }
  res.json({ total_weight_kg: r3(total), bars })
})

// Shuttering area
router.post('/shuttering', (req, res) => {
  const { length_m, height_m, sides } = req.body
  const L = Number(length_m)||0
  const H = Number(height_m)||0
  const s = Number(sides)||2
  if(L<=0||H<=0) return res.status(400).json({ error: 'Invalid dimensions' })
  const area = L * H * s
  res.json({ area_m2: r3(area) })
})

// Plaster: inputs wall_area_m2, thickness_mm (plaster thickness)
router.post('/plaster', (req, res) => {
  const { area_m2, thickness_mm } = req.body
  const A = Number(area_m2)||0
  const th = (Number(thickness_mm)||12)/1000
  if(A<=0||th<=0) return res.status(400).json({ error: 'Invalid inputs' })
  const vol = A * th // m3
  // assume plaster mortar ratio 1:4 (cement:sand)
  const totalParts = 1 + 4
  const cement_vol = vol * (1/totalParts)
  const cement_weight = cement_vol * 1440
  const cement_bags = cement_weight / 50
  const sand_m3 = vol * (4/totalParts)
  res.json({ volume_m3: r3(vol), cement_bags: r3(cement_bags), sand_m3: r3(sand_m3) })
})

// Tiles: floor area and tile size
router.post('/tiles', (req, res) => {
  const { floor_area_m2, tile_length_mm, tile_width_mm } = req.body
  const A = Number(floor_area_m2)||0
  const tl = (Number(tile_length_mm)||600)/1000
  const tw = (Number(tile_width_mm)||600)/1000
  if(A<=0) return res.status(400).json({ error: 'Invalid area' })
  const tile_area = tl * tw
  const tiles_needed = Math.ceil(A / tile_area * 1.05) // 5% wastage
  res.json({ tiles_needed })
})

// Cost snapshot
router.post('/cost', (req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items : []
  let total = 0
  const breakdown = []
  for(const it of items){
    const qty = Number(it.quantity)||0
    const uc = Number(it.unit_cost)||0
    const cost = qty * uc
    breakdown.push({ name: it.name||'item', quantity: qty, unit_cost: uc, cost: r3(cost) })
    total += cost
  }
  res.json({ total_cost: r3(total), breakdown })
})

module.exports = router
